/**
 * This is a class that tests the Deck class.
 */
public class DeckTester {

	/**
	 * The main method in this class checks the Deck operations for consistency.
	 *	@param args is not used.
	 */
	public static void main(String[] args) {
		String[] ranks1 = {"D", "E", "F"};
		String[] suits1 = {"Apple", "Banana"}; 
		int[] pointValues1 = {4, 5, 6};
		Deck deck1 = new Deck(ranks1, suits1, pointValues1);
		String[] ranks2 = {"Ace", "Two", "Three", "Four"};
		String[] suits2 = {"Hearts", "Spades"}; 
		int[] pointValues2 = {1, 2, 3, 4};
		Deck deck2 = new Deck(ranks2, suits2, pointValues2);
		String[] ranks3 = {};
		String[] suits3 = {}; 
		int[] pointValues3 = {};
		Deck deck3 = new Deck(ranks3, suits3, pointValues3);
		System.out.println("--------------------");
		System.out.println("DECK EMPTY CHECKS");
		System.out.println("--------------------");
		System.out.println("IS DECK 1 EMPTY? " + deck1.isEmpty()); // should be false
		System.out.println("IS DECK 2 EMPTY? " + deck2.isEmpty()); // should be false
		System.out.println("IS DECK 3 EMPTY? " + deck3.isEmpty()); // should be true
		System.out.println("--------------------");
		System.out.println("DECK SIZE CHECKS");
		System.out.println("--------------------");
		System.out.println("DECK 1 SIZE: " + deck1.size()); // should be 6
		System.out.println("DECK 2 SIZE: " + deck2.size()); // should be 8
		System.out.println("DECK 3 SIZE: " + deck3.size()); // should be 0
		System.out.println("--------------------");
		System.out.println("CARD DEAL CHECKS");
		System.out.println("--------------------");
		System.out.println(deck1.deal());
		System.out.println(deck2.deal());
		System.out.println(deck3.deal());
		System.out.println("--------------------");
		System.out.println("DECK TO STRING");
		System.out.println("--------------------");
		System.out.println("Deck 1");
		System.out.println(deck1.toString());
		System.out.println("Deck 2");
		System.out.println(deck2.toString());
		System.out.println("Deck 3");
		System.out.println(deck3.toString());
}
}